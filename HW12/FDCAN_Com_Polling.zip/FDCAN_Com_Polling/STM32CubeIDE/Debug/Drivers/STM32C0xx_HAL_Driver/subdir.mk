################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_cortex.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_dma.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_dma_ex.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_exti.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_fdcan.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_flash.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_flash_ex.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_gpio.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_pwr.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_pwr_ex.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_rcc.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_rcc_ex.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_uart.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_uart_ex.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_usart.c \
/home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_usart_ex.c 

OBJS += \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_cortex.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma_ex.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_exti.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_fdcan.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash_ex.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_gpio.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr_ex.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc_ex.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart_ex.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart.o \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart_ex.o 

C_DEPS += \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_cortex.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma_ex.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_exti.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_fdcan.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash_ex.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_gpio.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr_ex.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc_ex.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart_ex.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart.d \
./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart_ex.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_cortex.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_cortex.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_dma.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma_ex.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_dma_ex.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_exti.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_exti.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_fdcan.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_fdcan.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_flash.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash_ex.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_flash_ex.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_gpio.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_gpio.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_pwr.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr_ex.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_pwr_ex.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_rcc.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc_ex.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_rcc_ex.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_uart.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart_ex.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_uart_ex.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_usart.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"
Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart_ex.o: /home/gaiosa/ME-433/ME-433/HW12/FDCAN_Com_Polling/Drivers/STM32C0xx_HAL_Driver/Src/stm32c0xx_hal_usart_ex.c Drivers/STM32C0xx_HAL_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0plus -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32C092xx -DUSE_NUCLEO_64 -c -I../../Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc -I../../Drivers/STM32C0xx_HAL_Driver/Inc/Legacy -I../../Drivers/CMSIS/Device/ST/STM32C0xx/Include -I../../Drivers/CMSIS/Include -I../../Drivers/BSP/STM32C0xx_Nucleo -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Drivers-2f-STM32C0xx_HAL_Driver

clean-Drivers-2f-STM32C0xx_HAL_Driver:
	-$(RM) ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_cortex.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_cortex.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_cortex.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_cortex.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma_ex.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma_ex.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma_ex.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_dma_ex.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_exti.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_exti.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_exti.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_exti.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_fdcan.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_fdcan.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_fdcan.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_fdcan.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash_ex.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash_ex.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash_ex.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_flash_ex.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_gpio.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_gpio.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_gpio.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_gpio.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr_ex.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr_ex.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr_ex.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_pwr_ex.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc_ex.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc_ex.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc_ex.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_rcc_ex.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart_ex.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart_ex.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart_ex.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_uart_ex.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart.su ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart_ex.cyclo ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart_ex.d ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart_ex.o ./Drivers/STM32C0xx_HAL_Driver/stm32c0xx_hal_usart_ex.su

.PHONY: clean-Drivers-2f-STM32C0xx_HAL_Driver

